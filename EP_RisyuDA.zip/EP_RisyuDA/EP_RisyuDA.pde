// EP演習 発表用ゲーム「履修打（りしゅだ）」

String status = "taiki"; 
String typedWord = "";
String judge = "";
String Grade = "S";
String[] words = {"English", "Computer Programming", "Essential FMS", "Linear Algebra", "Introductory Course for IMS", "Calculus", "Academic Literacy", "IM Seminar", "Exercise in EP"};
int[] numbers = new int[9];
int count = 3;
int y = -100;
int R = 255;
int G = 255;
int B = 255;
int C = 255;
int i = 0;
int GP = 4;
int score = 0;
int shakeDuration = 10;
int shakeAmount = 20;
int shakeFrame = 0;
float speed = 12;
float acceleration = 0.965;
boolean countdownFinished = false;
boolean constantSpeed = false;
boolean isShaking = false;

void setup()
{
  size(1800, 860);
  textAlign(CENTER, CENTER);
}

void draw()
{
  if(status == "taiki")
  {
     background(0);
     fill(255);
     textSize(200);
     text("Risyu DA", 900, 300);
     fill(C);
     noStroke();
     rect(650, 500, 500, 200);
     fill(0);
     textSize(100);
     text("Start", 900, 600);
     if(mouseX >= 650 && mouseX <= 1150 && mouseY >= 500 && mouseY <= 700)
     {
       C = 200;
     }
     else
     {
       C = 255;
     }
  }
  
  else if(status == "countdown")
  {
    background(0);
    fill(255);
    frameRate(1);
    textSize(100);
    if (!countdownFinished)
    {
    if (count >= 1)
    {
      text(count, width / 2, height / 2);
      count--;
    }
    else
    {
      text("Start!", width / 2, height / 2);
      countdownFinished = true;
      frameRate(60);
    }
  } 
  else
  {
    text("Start!", width / 2, height / 2);
    status = "gaming";
  }
  }
  
  else if(status == "gaming")
  {
    frameRate(60);
    background(255);
    fill(0);
    textSize(55);
    text(typedWord, 350, 280);
    
    float xOffset = 0;
    if (isShaking && shakeFrame < shakeDuration)
    {
      xOffset = random(-shakeAmount, shakeAmount);  // ランダムに左右へ揺らす
      shakeFrame++;
    }
    else
    {
      isShaking = false;  // 揺れが終わったらフラグをオフにする
    }
    
    rect(700, 0, 1100, 860);
    fill(200);
    rect(0, 560, 700, 300);
    
    fill(R, G, B);
    textSize(70);
    if(i < 9)
    {
      text(words[i], 1250 + xOffset, y);
    }
    fill(0);
    textSize(70);
    text("Grade : " + Grade, 350, 710);
    if(speed > 1.0 && !constantSpeed)
    {
      y += speed;
      speed *= acceleration;
      if(speed <= 1.0)
      {
        //println(y);
        constantSpeed = true;
        speed = 1.0;
      }
    }
    else if(constantSpeed)
    {
      y += speed;
    }
    if(y <= 364.5)
    {
      GP = 4;
      Grade = "S";
      R = 255;
      G = 255;
      B = 255;
    }
    if(y > 364.5)
    {
      GP = 3;
      Grade = "A";
      R = 0;
      G = 0;
      B = 255;
    }
    if(y > 523)
    {
      GP = 2;
      Grade = "B";
      R = 255;
      G = 255;
      B = 0;
    }
    if(y > 700)
    {
      GP = 1;
      Grade = "C";
      R = 255;
      G = 0;
      B = 0;
    }
    if(y > 890)
    {
      GP = 0;
      Grade = "F";
      typedWord = "";
    }
    if(y > 1000)
    {
      y = -100;
      GP = 4;
      speed = 12;
      constantSpeed = false;
      i++;
    }
    if(judge != "")
    {
      if(judge.equals(words[i]))
      {
        delay(500);
        if(i == 1)
        {
          score += 4 * GP;
        }
        else
        {
          score += 2 * GP;
        }
        judge = "";
        y = -100;
        speed = 12;
        GP = 4;
        constantSpeed = false;
        i++;
      }
      else
      {
        isShaking = true;
        shakeFrame = 0;
        delay(500);
        judge = "";
      }
    }
    
    if(i >= 9)
      {
        fill(0);
        background(157, 204, 224);
        status = "result1";
      }

  /*
  fill(255);
  textSize(30);
   text("i = " + i, 200, 50);
   text("y = " + y, 200, 100);
   text("speed = " + speed, 200, 150);
   text("GP = " + GP, 200, 200);
   text("score = " + score, 200, 250);
   text("constantSpeed : " + constantSpeed, 200, 300);
   */
   
  }
  
  else if(status == "result1")
  {
    delay(1000);
    textSize(70);
    text("Your GPA is ", 620 + 150, 430);
    status = "result2";
  }
  
  else if(status == "result2")
  {
    delay(1500);
    textSize(100);
    text(nf((float)score / 20.0, 0, 2), 900 + 150, 425);
  }
  
  //println(status);
  //println(typedWord);
  //println((String)words[i]);
}

void keyTyped()
{
  if(key == BACKSPACE)
  {
    typedWord = "";
  }
  else if(key == ENTER)
  {
    judge = typedWord;
    typedWord = "";
  }
  else if(y <= 890)
  {
    typedWord += key;
  }
}

void mousePressed()
{
  if(status == "taiki" && mouseX >= 650 && mouseX <= 1150 && mouseY >= 500 && mouseY <= 700)
  {
    status = "countdown";
  }
}
